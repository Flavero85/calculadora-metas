document.addEventListener('DOMContentLoaded', () => {

    // ==================================================
    // --- FUNÇÕES GLOBAIS E AJUDANTES ---
    // ==================================================

    /**
     * Copia um texto para a área de transferência de forma assíncrona.
     * @param {string} text O texto a ser copiado.
     * @returns {Promise<boolean>} True se a cópia foi bem-sucedida, false caso contrário.
     */
    async function copyTextToClipboard(text) {
        if (!text) return false;
        try {
            await navigator.clipboard.writeText(text);
            return true;
        } catch (err) {
            console.error('Falha ao copiar texto: ', err);
            return false;
        }
    }

    /**
     * Aplica um feedback visual a um elemento clicado.
     * @param {HTMLElement} element O elemento que receberá o feedback.
     */
    function applyVisualFeedback(element) {
        if (element.classList.contains('copied')) return; // Previne múltiplos cliques
        element.classList.add('copied');
        setTimeout(() => {
            element.classList.remove('copied');
        }, 1200);
    }

    /**
     * Retorna mensagens de saudação e despedida baseadas na hora do dia.
     * @returns {{greeting: string, farewell: string}}
     */
    function getDailyMessages() {
        const h = new Date().getHours();
        if (h >= 5 && h < 12) return { greeting: 'Olá, bom dia! ☀️', farewell: 'tenha um ótimo dia! ☀️' };
        if (h >= 12 && h < 18) return { greeting: 'Olá, boa tarde! 🌤️', farewell: 'tenha uma ótima tarde! 🌤️' };
        return { greeting: 'Olá, boa noite! 🌙', farewell: 'tenha uma excelente noite! 🌙' };
    }

    /**
     * Atualiza as mensagens dinâmicas (inicial/final) e o campo de nome.
     */
    function updateDynamicMessages() {
        const userName = localStorage.getItem('userName') || 'Atendente';
        const { greeting, farewell } = getDailyMessages();
        const elInicial = document.getElementById('mensagem-inicial');
        const elFinal = document.getElementById('mensagem-final');

        if (elInicial) {
            const initialMessage = `${greeting} Sou ${userName} do Suporte Técnico da Desktop e estou aqui para ajudar. Com quem estou falando e no que posso ajudar? 😊`;
            elInicial.textContent = initialMessage;
            elInicial.dataset.original = initialMessage;
        }
        if (elFinal) {
            const finalMessage = `Agradecemos por escolher nossos serviços! Sua opinião é muito importante para mim, por isso, por favor, me avalie. Isso me ajuda a melhorar ainda mais na empresa e pessoalmente. Desde já, agradeço sua avaliação! 🌟 Estamos sempre à sua disposição, por chat e através do número 103-44. ${farewell} e tudo de bom!`;
            elFinal.textContent = finalMessage;
            elFinal.dataset.original = finalMessage;
        }
        const nameInput = document.getElementById('nameInput');
        if (nameInput) nameInput.value = userName;
    }

    /**
     * Salva o nome do usuário no armazenamento local.
     */
    function saveName() {
        const nameInput = document.getElementById('nameInput');
        const userName = nameInput.value.trim();
        if (userName) {
            localStorage.setItem('userName', userName);
            updateDynamicMessages();
            alert(`Nome "${userName}" salvo!`);
        } else {
            alert('Por favor, digite um nome.');
        }
    }
    
    // ==================================================
    // --- INICIALIZAÇÃO E EVENTOS GERAIS ---
    // ==================================================
    
    updateDynamicMessages();

    const saveButton = document.getElementById('saveButton');
    if (saveButton) saveButton.addEventListener('click', saveName);

    const nameInput = document.getElementById('nameInput');
    if (nameInput) nameInput.addEventListener('keyup', (e) => { if (e.key === 'Enter') saveName(); });

    const clickableContainer = document.querySelector('#scripts-container, .page-container, .content-container');
    if (clickableContainer) {
        clickableContainer.addEventListener('click', async (e) => {
            const item = e.target.closest('.script-line, .link-item');
            if (!item) return;
            const text = item.dataset.copyText || item.dataset.original || item.textContent;
            if (await copyTextToClipboard(text)) {
                applyVisualFeedback(item);
            }
        });
    }

    // ==================================================
    // --- LÓGICA ESPECÍFICA DE CADA PÁGINA ---
    // ==================================================

    // --- PÁGINA "LINKS IMPORTANTES" ---
    const copyAllLinksButton = document.getElementById('copyAllLinksButton');
    if (copyAllLinksButton) {
        copyAllLinksButton.addEventListener('click', async () => {
            const links = Array.from(document.querySelectorAll('.link-item'))
                .map(l => `${l.textContent.trim()}: ${l.dataset.copyText}`)
                .join('\n');
            if (await copyTextToClipboard(links)) {
                const originalText = copyAllLinksButton.textContent;
                copyAllLinksButton.textContent = 'Copiado!';
                setTimeout(() => {
                    copyAllLinksButton.textContent = originalText;
                }, 1500);
            }
        });
    }

    // --- PÁGINA "MODELOS PRONTOS" (FILTRO) ---
    const searchModelInput = document.getElementById('searchModel');
    if (searchModelInput) {
        searchModelInput.addEventListener('keyup', () => {
            const filter = searchModelInput.value.toLowerCase();
            document.querySelectorAll('.model-button').forEach(btn => {
                const col = btn.closest('.column');
                if (col) {
                    col.style.display = btn.textContent.toLowerCase().includes(filter) ? '' : 'none';
                }
            });
        });
    }

    // --- PÁGINA "LENTIDAO" (AGENDAMENTO DINÂMICO) ---
    const agendamentoContainer = document.getElementById('data-agendamento');
    if (agendamentoContainer) {
        const dataInput = document.getElementById('data-agendamento');
        const horaInicioInput = document.getElementById('hora-inicio');
        const horaFimInput = document.getElementById('hora-fim');

        function updateAgendamento() {
            if (!dataInput.value || !horaInicioInput.value || !horaFimInput.value) return;

            const dataSelecionada = new Date(dataInput.value + 'T00:00:00');
            const dataAtual = new Date();
            dataAtual.setHours(0, 0, 0, 0);

            const umDia = 1000 * 60 * 60 * 24;
            const diffDias = Math.ceil((dataSelecionada - dataAtual) / umDia);
            
            let dia = String(dataSelecionada.getDate()).padStart(2, '0');
            let mes = String(dataSelecionada.getMonth() + 1).padStart(2, '0');
            let dataFormatada = `${dia}/${mes}`;

            let diasDaSemana = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
            let hojeOuAmanha = '';
            if (diffDias === 0) hojeOuAmanha = `hoje (${dataFormatada})`;
            else if (diffDias === 1) hojeOuAmanha = `amanhã (${dataFormatada})`;
            else hojeOuAmanha = `${diasDaSemana[dataSelecionada.getDay()]} (${dataFormatada})`;

            const horaInicio = horaInicioInput.value;
            const horaFim = horaFimInput.value;
            const confirmarFrase = `Verifiquei em sistema e a primeira data disponível para ${hojeOuAmanha} no período das ${horaInicio} às ${horaFim}. Posso agendar? 👍`;
            const finalizarFrase = `Prontinho! O agendamento foi realizado para ${hojeOuAmanha}, no período das ${horaInicio} às ${horaFim}. Lembre-se que é necessário ter um maior de 18 anos no local para acompanhar a visita técnica, Ok? 😊`;

            const confirmarEl = document.getElementById('confirmar-agendamento');
            const finalizarEl = document.getElementById('finalizar-agendamento');
            
            confirmarEl.textContent = confirmarFrase;
            confirmarEl.dataset.original = confirmarFrase;
            finalizarEl.textContent = finalizarFrase;
            finalizarEl.dataset.original = finalizarFrase;
        }

        dataInput.addEventListener('input', updateAgendamento);
        horaInicioInput.addEventListener('input', updateAgendamento);
        horaFimInput.addEventListener('input', updateAgendamento);
        updateAgendamento();
    }

    // --- PÁGINA "ENCAIXE" (FORMULÁRIO AUTOMÁTICO) ---
    const formEncaixe = document.getElementById('form-encaixe');
    if (formEncaixe) {
        const cityData = {
            'Amparo': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Campinas': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Holambra': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Hortolândia': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Jaguariúna': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Lindoia': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Monte Alegre do Sul': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Monte Mor': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Pedreira': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Santo Antônio de Posse': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Serra Negra': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Campinas' },'Capivari': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Alumínio': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Angatuba': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Aracoiaba da Serra': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Bofete': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Boituva': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Campina do Monte Alegre': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Capela do Alto': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Cerquilho': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Cesario Lange': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Conchas': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Elias Fausto': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Ipero': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Itapetininga': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Itu': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Jumirim': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Laranjal Paulista': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Pereiras': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Pilar do Sul': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Porangaba': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Quadra': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'RAFARD': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Rio das Pedras': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Saltinho': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Salto': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Salto de Pirapora': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Sarapui': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Sorocaba': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Tatui': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Tiete': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },'Votorantim': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sorocaba' },
            'Aguaí': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Americana': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Araras': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Araucária': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Artur Nogueira': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Santa Bárbara DOeste': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Casa Branca': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Engenheiro Coelho': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Conchal': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Cordeirópolis': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Cosmópolis': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Estiva Gerbi': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Iracemápolis': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Piracicaba': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Leme': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Limeira': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Paulínia': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Sumaré': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Mogi Guaçu': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Mogi Mirim': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Nova Odessa': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Pirassununga': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Porto Ferreira': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Santa Cruz das Palmeiras': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Rio Claro': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Santa Rita do Passa Quatro': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Santa Gertrudes': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },'Tambaú': { cluster: 'REGIONAL CENTRAL', territory: 'Território de Sumaré' },
            'Araçariguama': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Atibaia': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Jundiaí': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Barueri': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Bom Jesus dos Perdões': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Bragança Paulista': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Cabreúva': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Caieiras': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Campo Limpo Paulista': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Carapicuíba': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Francisco Morato': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Franco da Rocha': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Indaiatuba': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Itupeva': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Jarinu': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Louveira': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Mairiporã': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Nazaré Paulista': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Piracaia': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Valinhos': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Várzea Paulista': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },'Vinhedo': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Jundiaí' },
            'Cubatão': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Diadema': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Guarujá': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Itanhaém': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Mongaguá': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Peruíbe': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Praia Grande': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'São Bernardo do Campo': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Santo André': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'Santos': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'São Caetano Sul': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },'São Vicente': { cluster: 'REGIONAL SUDESTE', territory: 'Território de Praia Grande' },
            'Biritiba Mirim': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Caçapava': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Guararema': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Igaratá': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Jacareí': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Mogi das Cruzes': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'São José dos Campos': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Salesópolis': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Santa Branca': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'São Paulo': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Taubaté': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },'Tremembé': { cluster: 'REGIONAL SUDESTE', territory: 'Território de São José dos Campos' },
            'Cravinhos': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Araraquara': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Americo Brasiliense': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Boa Esperança do Sul': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Bocaina': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Borborema': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Descalvado': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Dobrada': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Dourado': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Gaviao Peixoto': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Guariba': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Guatapará': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Ibate': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Ibitinga': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Itaju': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Itápolis': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Matao': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Motuca': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Nova Europa': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Ribeirão Bonito': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Ribeirão Preto': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Rincao': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Santa Ernestina': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Santa Lucia': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Sao Carlos': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'São Joaquim da Barra': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Tabatinga': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },'Trabiju': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Araraquara' },
            'Bady Bassitt': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Barretos': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Bebedouro': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Cândido Rodrigues': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Colina': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Cristais Paulista': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Fernando Prestes': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Franca': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Guaíra': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Guarapiaçu': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Itajobi': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Itirapua': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Pitangueiras': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Jaborandi': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Jaboticabal': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Mirassol': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Monte Alto': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Olímpia': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Patrocinio Paulista': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Pindorama': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Ribeirao Corrente': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'São José do Rio Preto': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },'Santa Adélia': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território de Barretos' },
            'Águas de Santa Bárbara': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Agudos': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Arandu': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Arealva': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Areiópolis': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Avai': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Avare': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Avaré': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Bariri': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Barra Bonita': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Batucatu': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Bauru': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Botucatu': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Borebi': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Cafelândia': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Cedral': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Cerqueira César': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Dois Córregos': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Guarantã': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Iaras': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Igaraçu do Tietê': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Itaí': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Itapuí': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Itatinga': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Jau': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Jaú': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Lençóis Paulista': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Lins': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Macatuba': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Manduri': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Mineiros do Tietê': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Novo Horizonte': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Óleo': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Paranapanema': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Pardinho': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Pederneiras': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Pirajuí': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Piratininga': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Pratânia': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Presidente Alves': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'São Manuel': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' },'Serra Azul': { cluster: 'REGIONAL CENTRO OESTE', territory: 'Território Lençóis Paulista' }
        };

        const todasCidades = Object.keys(cityData).sort();
        const cidadeDatalist = document.getElementById('cidades');
        todasCidades.forEach(cidade => {
            cidadeDatalist.appendChild(Object.assign(document.createElement('option'), { value: cidade }));
        });
        
        const cidadeInput = document.getElementById('cidade');
        cidadeInput.addEventListener('input', () => {
            const territorioInput = document.getElementById('territorio');
            const clusterInput = document.getElementById('cluster');
            const data = cityData[cidadeInput.value];
            territorioInput.value = data ? data.territory : '';
            clusterInput.value = data ? data.cluster : '';
        });
        
        document.getElementById('gerarEncaixeButton').addEventListener('click', () => {
            const data = {
                setor: document.getElementById('setor').value,
                protocolo: document.getElementById('protocolo').value,
                cidade: document.getElementById('cidade').value,
                territorio: document.getElementById('territorio').value,
                cluster: document.getElementById('cluster').value,
                telefone: document.getElementById('telefone').value,
                dataEncaixe: document.getElementById('dataEncaixe').value,
                periodo: document.getElementById('periodo').value,
                motivo: document.getElementById('motivo').value
            };

            if (Object.values(data).some(v => !v)) {
                alert('Preencha todos os campos antes de gerar o encaixe.');
                return;
            }

            const [ano, mes, dia] = data.dataEncaixe.split('-');
            const dataFormatada = `${dia}/${mes}/${ano}`;
            const resultadoTexto = `*-- Solicitação de Encaixe  --*\nSetor: *${data.setor}*\nProtocolo / Caso: *${data.protocolo}*\nCidade: *${data.cidade}*\nTerritório: *${data.territorio}*\nCluster: *${data.cluster}*\nTelefone: *${data.telefone}*\nData do Encaixe: *${dataFormatada}*\nPeríodo: *${data.periodo}*\nMotivo:  *${data.motivo}*`;
            
            document.getElementById('resultado').textContent = resultadoTexto;
            document.getElementById('resultado-container').classList.remove('hidden');
        });

        document.getElementById('limparFormularioButton').addEventListener('click', () => {
            formEncaixe.reset();
            document.getElementById('territorio').value = '';
            document.getElementById('cluster').value = '';
            document.getElementById('resultado-container').classList.add('hidden');
        });

        document.getElementById('copiarResultadoButton').addEventListener('click', async (e) => {
            const texto = document.getElementById('resultado').textContent;
            if (await copyTextToClipboard(texto)) {
                const btn = e.target;
                const originalText = btn.textContent;
                btn.textContent = 'Copiado!';
                setTimeout(() => { btn.textContent = originalText; }, 1500);
            }
        });
    }

    // --- PÁGINA "METAS" (COM SALVAMENTO AUTOMÁTICO E CONTADOR) ---
    const atendimentosInput = document.getElementById('atendimentosInput');
    if (atendimentosInput) {
        const metas = [
            { id: 1, target: 550, reward: 300 },
            { id: 2, target: 750, reward: 400 },
            { id: 3, target: 850, reward: 500 },
            { id: 4, target: 950, reward: 700 }
        ];
        const metasContainer = document.getElementById('metas-container');
        const summaryText = document.getElementById('summary-text');
        const incrementButton = document.getElementById('incrementButton');

        function renderMetas() {
            metasContainer.innerHTML = '';
            metas.forEach(meta => {
                const metaElement = document.createElement('div');
                metaElement.className = 'meta-item';
                metaElement.innerHTML = `
                    <div class="meta-header">
                        <span class="meta-label">Faixa ${meta.id}: ${meta.target} atendimentos (R$ ${meta.reward})</span>
                        <span class="meta-percentage" id="meta${meta.id}-percent">0%</span>
                    </div>
                    <div class="progress-bar-background">
                        <div class="progress-bar-fill" id="meta${meta.id}-fill"></div>
                    </div>
                `;
                metasContainer.appendChild(metaElement);
            });
        }

        function updateProgress() {
            const currentValue = parseInt(atendimentosInput.value) || 0;
            localStorage.setItem('atendimentosCount', currentValue);

            let highestAchieved = null;
            metas.forEach(meta => {
                const percent = Math.min(100, (currentValue / meta.target) * 100);
                const fill = document.getElementById(`meta${meta.id}-fill`);
                const percentText = document.getElementById(`meta${meta.id}-percent`);
                fill.style.width = `${percent}%`;
                percentText.textContent = `${Math.floor(percent)}%`;
                if (percent >= 100) {
                    fill.classList.add('completed');
                    highestAchieved = meta;
                } else {
                    fill.classList.remove('completed');
                }
            });
            
            if (!highestAchieved) {
                const faltam = metas[0].target - currentValue;
                summaryText.innerHTML = `Você ainda não atingiu a primeira meta. Faltam <strong>${faltam > 0 ? faltam : 0}</strong> atendimentos para a Faixa 1.`;
                summaryText.className = 'summary-box';
            } else {
                const nextMetaIndex = metas.findIndex(m => m.id === highestAchieved.id) + 1;
                if (nextMetaIndex < metas.length) {
                    const nextMeta = metas[nextMetaIndex];
                    const faltam = nextMeta.target - currentValue;
                    summaryText.innerHTML = `Parabéns! Você atingiu a <strong>Faixa ${highestAchieved.id} (R$ ${highestAchieved.reward})</strong>. Faltam <strong>${faltam > 0 ? faltam : 0}</strong> para a próxima!`;
                    summaryText.className = 'summary-box completed';
                } else {
                    summaryText.innerHTML = `INCRÍVEL! 🏆 Você atingiu a meta máxima de <strong>R$ ${highestAchieved.reward}</strong>!`;
                    summaryText.className = 'summary-box completed';
                }
            }
        }
        
        renderMetas();
        const savedAtendimentos = localStorage.getItem('atendimentosCount');
        if (savedAtendimentos) {
            atendimentosInput.value = savedAtendimentos;
        }
        updateProgress();
        atendimentosInput.addEventListener('input', updateProgress);
        
        if (incrementButton) {
            incrementButton.addEventListener('click', () => {
                let currentValue = parseInt(atendimentosInput.value) || 0;
                currentValue++;
                atendimentosInput.value = currentValue;
                atendimentosInput.dispatchEvent(new Event('input'));
            });
        }
    }
});